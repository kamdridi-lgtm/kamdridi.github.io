
// smooth scroll
document.querySelectorAll('.links a').forEach(a=>{
  a.onclick=e=>{
    if(a.hash){
      e.preventDefault()
      document.querySelector(a.hash).scrollIntoView({behavior:'smooth'})
    }
  }
})

// gallery lightbox
document.querySelectorAll('.gallery img').forEach(img=>{
  img.onclick=()=>{
    const o=document.createElement('div')
    o.style.position='fixed'
    o.style.inset=0
    o.style.background='rgba(0,0,0,.95)'
    o.style.display='flex'
    o.style.alignItems='center'
    o.style.justifyContent='center'
    o.onclick=()=>o.remove()
    const f=document.createElement('img')
    f.src=img.src
    f.style.maxWidth='92%'
    f.style.maxHeight='92%'
    o.appendChild(f)
    document.body.appendChild(o)
  }
})
